# AutoBuilt — build status / where I left off

_Last updated by Claude (Sonnet 5) session on 2026-09-23 (Cal.com integration session)._

## READ THIS FIRST (2026-09-23, latest session)
- **Nothing is live yet.** All of login/multi-tenant auth AND the new real Cal.com
  webhook integration are built and committed locally, but the user still needs to
  do ONE GitHub "Upload files" drag-and-drop to ship everything at once. Until that
  upload happens, the live app at autobuilt-app.onrender.com is still running the
  OLD pre-auth code.
- **Ready-to-upload folder on the Mac:** `~/Downloads/autobuilt-ready-calcom/autobuilt-app/`
  — this has EVERYTHING (auth + Cal.com integration together). Drag that folder's
  CONTENTS into the GitHub upload page. Every other `autobuilt-*` folder in Downloads
  (`autobuilt-final`, `autobuilt-updated`, `autobuilt-updated-v2`, etc.) is stale from
  earlier sessions — ignore them, this is the current one.
- **Do the upload as ONE drag** of the whole folder's contents (web/ AND server/
  together). Uploading only one half will break the live app (old frontend has no
  login screen; new backend requires a token on every route except `/api/auth/*`
  and `/api/public/:slug/*`).
- Demo login after upload: **demo@fadedistrict.example / FadeDistrict2026!**
  (auto-created by seed.js on first run against an empty database, since Render's
  disk is ephemeral and wipes on every deploy anyway — see Render section below).
- Render: on Starter ($7/mo) for the `autobuilt-api` web service — user already
  did this. Still no persistent disk / managed Postgres, so the DB resets to a
  fresh demo business on every deploy. Not urgent while still testing; matters
  once there's a real client with real data to keep.
- **Twilio: fully dropped for now, per the user's explicit decision.** Do not touch
  Twilio again unless the user brings it up. Real SMS/A2P registration happens
  later, per real paying client, under that client's own name. (History: AutoBuilt's
  own Brand was Approved but the Campaign was Rejected because AutoBuilt — the
  platform — was the wrong entity to register as sender identity when end customers
  only ever see the individual client business's name. Rather than re-register
  AutoBuilt for Austin's own manual prospecting, the user chose to just wait for a
  real client and use mock mode until then. Nothing left to do here.)
- **NEW this session: real Cal.com webhook integration**, built and tested locally,
  end to end, including against a real Cal.com event type + webhook Austin already
  has configured (see "Cal.com integration" section below). This is fully separate
  from Twilio — Cal.com handles bookings, Twilio would handle texting; only Twilio
  was dropped.

## Cal.com integration (built 2026-09-23, NOT LIVE until the GitHub upload happens)
- Real webhook receiver: `POST /api/public/:slug/calcom-webhook`. Verifies Cal.com's
  `X-Cal-Signature-256` HMAC header against a per-business secret, then handles
  `BOOKING_CREATED` (creates the appointment + customer), `BOOKING_CANCELLED`
  (marks cancelled), and `BOOKING_RESCHEDULED` (updates the existing appointment's
  time rather than creating a duplicate). Retries from Cal.com are idempotent via
  the booking's `uid`, stored as `appointments.external_ref`.
- Every business gets its own random webhook secret at signup (`businesses.calcom_webhook_secret`).
  Settings → "Cal.com" shows the exact webhook URL + secret to paste into Cal.com's
  own Webhooks screen (Settings → Developer → Webhooks in Cal.com, or per-event-type
  under an Event Type's own "Webhooks" tab).
- A service can be linked to a specific Cal.com event type
  (`services.calcom_event_type_id`) so a booking on that event type maps to the
  right AutoBuilt service (price/duration) instead of an unlinked appointment.
  `PATCH /api/business/calcom-webhook-info/link-service` sets this (no UI for it
  yet — fine for now since the demo is pre-linked, see below).
- **Already configured on Austin's own real Cal.com account** (app.cal.com,
  already logged in this session) as a live test rig for the demo business:
  - Event type "Signature Fade", 45 min, at `cal.com/austinbr/signature-fade`
    (event type ID `7202246` — hardcoded into `seed.js` so the demo service
    auto-links to it on every fresh seed).
  - Added a required "Phone number" booking question (was present but hidden/optional
    by default) — the webhook needs a phone number to text reminders to.
  - Created a webhook on that event type, subscribed to Booking created/canceled/
    rescheduled, pointed at
    `https://autobuilt-api.onrender.com/api/public/fade-district-demo/calcom-webhook`
    with secret `fade-district-demo-secret-2026` (this exact secret is also
    hardcoded as the demo business's `calcom_webhook_secret` in seed.js — they
    match on purpose, so this webhook will work the instant the code goes live,
    no extra copy-pasting needed).
  - **Once the GitHub upload ships this code**, a real test is one real booking away:
    go to `cal.com/austinbr/signature-fade`, book a real slot with a real phone
    number, and it should appear in the AutoBuilt app under that customer within
    seconds — no Test Tools, no mock data, an actual Cal.com webhook hitting the
    actual backend.
- Tested thoroughly against a local server before any of this was touched on
  Cal.com's side: valid signature accepted, invalid signature rejected (401),
  duplicate webhook delivery is a no-op (no duplicate appointment), cancel flips
  status to `cancelled`, reschedule updates the same appointment's time (not a
  new row), and `eventTypeId` correctly resolves to the linked service.
- A real client's own signup gets its own random secret automatically — this
  hardcoded demo secret only ever backs the one demo business, never a real one.
- Not built yet (do only if it comes up): a Settings UI for linking a service to
  a Cal.com event type (currently API-only), and rotating a business's webhook
  secret if it's ever compromised.

## Live URLs
- App (frontend, Render static site): https://autobuilt-app.onrender.com
- API (backend, Render web service, free tier): https://autobuilt-api.onrender.com
- GitHub repo: https://github.com/AustinBriney/AutoBuilt-app
  - NOTE: files live under the `autobuilt-app/` subfolder in the repo (nested one level).
  - Render root dirs: web = `autobuilt-app/web`, server = `autobuilt-app/server`.
  - Static site `/api/*` is a Rewrite → `https://autobuilt-api.onrender.com/api/*`.

## Deployment mechanism (IMPORTANT)
- Cannot `git push` from this cloud container — the sandbox git proxy blocks pushes to
  this repo (403 "not in authorized repository set"). Same wall both sessions.
- The user's Mac ("austins-macbook-air-local") IS linked to the session via the
  remote-devices bridge → deploy by pushing from the Mac's shell (device_bash), which
  is not subject to the container proxy. Render auto-deploys on push.
- GitHub history diverged: web-upload commit on GitHub vs local commits here. When
  pushing from the Mac, may need `--force` onto main (confirm before forcing) or reset
  local to match remote then re-apply.

## Checklist from the user (2026-09-22)
- [ ] Recolor: kill green, clean/modern. (Local code already uses brand palette; the
      GREEN the user sees is the OLD version still deployed. Neutralize any green cast.)
- [ ] Pin bottom nav to bottom on all tabs (floats on Dashboard/Inbox/Customers; ok on Schedule).
- [ ] Seed exactly ONE of everything (1 appt, 1 customer, 1 inbox convo, 1 service, 1 schedule).
- [ ] Services + Schedule: add DELETE (not just hide). Edit hours in place. Weekly hours in AM/PM (not military).
- [ ] Settings: remove Automations tab; hide backend/Connected-services detail; keep plan display;
      clarify booking link; generalize for any plan/client.
- [ ] First-run onboarding: new client fills out info first, lands in Settings, ready immediately.
- [ ] Keep Test Tools (for Austin's own Twilio testing) for now.
- [ ] Mock client website for demo closing (mock-site/ exists — verify/polish).
- [ ] Verify Twilio registration status (check open Chrome tab).
- [ ] Triple-check backend for holes/bugs. Previous (non-Opus) model made changes that need review.

## Prior model's commit to REVIEW (may contain mistakes)
Commit 0841ae2 "Rebrand to clean palette, simplify seed, add onboarding, editable hours,
service delete, mock site" touched:
mock-site/index.html, server/src/db/schema.sql, server/src/db/seed.js,
server/src/routes/availability.js, server/src/routes/business.js, web/src/App.jsx,
web/src/lib/api.js, web/src/lib/format.js, web/src/lib/theme.jsx,
web/src/pages/Onboarding.{jsx,css}, web/src/pages/Schedule.{jsx,css}, web/src/pages/Settings.jsx

## Live state (verified 2026-09-22, Opus 4.8 session)
- App LIVE and CORRECT at autobuilt-app.onrender.com: warm palette (no green), bottom nav
  pinned, one-of-each seed (1 appt Dorian Lewis/Signature Fade, 1 customer, 1 inbox convo,
  1 service, 1 Mon 9AM-5PM hours), Settings simplified (no Automations tab, no backend
  connected-services; plan status "Active" kept; Test Tools kept), Hours show AM/PM with Edit,
  Schedule has delete for appts+services and edit-in-place hours.
- Mock client site LIVE at fade-district-demo-site.onrender.com (separate Render static site),
  pulls live services from the API, "Book" POSTs to /api/public/book → appointment appears in app.
- A PRIOR reset-cycle already pushed the corrected code to GitHub (user likely re-uploaded) and
  Render deployed it. So the "still green" the user saw is almost certainly the installed PWA /
  browser serving a CACHED old build — fix: remove from home screen & re-add, or hard refresh.
- Twilio: account exists (SID redacted — see Twilio console) but console tab is logged out;
  app runs in MOCK mode (no TWILIO_* env vars on Render). A2P/registration status not verifiable
  without login.

## Still local-only (needs a re-upload to ship — MINOR, app already works)
- Dashboard "today" timezone fix (commit 7f6c676) — live dashboard already shows today's appt
  correctly for the current seed; fix hardens evening/edge cases.
- Ready-to-upload folder placed on the Mac at ~/Downloads/autobuilt-updated/autobuilt-app/
  (drag that folder into the repo root on GitHub to ship the tz fix + this STATUS).

## Known minor polish (not yet done)
- Schedule "Upcoming" tab shows completed/past appts (no future-only filter).

## Progress log
- 2026-09-22: Confirmed deploy blocker + Mac bridge path. Reviewed prior model's work (solid).
  Fixed dashboard tz bug (committed locally). Verified the LIVE app + mock site are already
  correct across Dashboard/Settings/Schedule/Hours. Placed ready-to-upload folder on Mac.
- 2026-09-23 (late): User re-uploaded to GitHub but an OLDER folder copy — the dashboard tz fix
  (commit 7f6c676) is NOT in the deployed code (GitHub dashboard.js still uses date('now') UTC).
  Ran a LIVE end-to-end test: booked "Marcus Test Client" on fade-district-demo-site.onrender.com
  -> appeared in the app under Customers with "1 upcoming". Full loop confirmed live (CORS +
  /api rewrite working). NOTE: demo now has 2 customers (test data); redeploy reseeds to clean.
  Built end-of-night status board artifact: https://claude.ai/artifact/GhLLyDKb6FoJU5yA7EMZiR
  Key holes to fix before real clients: (1) seed runs on every deploy = wipes real data;
  (2) no auth / single-tenant; (3) SQLite non-durable on free tier; plus Twilio A2P not started.
- 2026-09-23 (Sonnet 5 session): User reviewed the status board, gave direction (login/data-safety
  first, then real Twilio texting; stay on Render; rename booking link). Researched pricing:
  Render Starter $7/mo (+ ~$1-2/mo disk, or ~$6/mo Postgres) fixes both holes above; Twilio real
  number ~$1.15-2.15/mo + ~$19.50 one-time A2P registration + $1.50/mo campaign fee.
  Built the actual login/multi-tenant system (see "READ THIS FIRST" above): JWT auth
  (signup/login/me), auth_accounts table, AsyncLocalStorage-based per-request business scoping
  replacing the old single-row assumption, slug-scoped public booking routes so the mock site and
  future real client sites can coexist, and an idempotent seed.js that now REFUSES to run if any
  business already exists (fixes the wipe-on-deploy risk permanently, independent of whatever the
  Render build command says). Frontend: new Login/Signup screen, AuthProvider holding the JWT,
  every api.js call now sends it. Verified end-to-end via curl: signup, login, wrong-password 401,
  unauthenticated 401, two separately-signed-up businesses see zero of each other's data, public
  booking works by slug. Committed locally (ee287cc, bbe0d28) — still needs the GitHub
  upload to go live. Also checked Render billing (Hobby/free workspace plan, no card, $0 owed —
  the $25 "Pro" plan the user saw is a team-seat plan, NOT required for a paid instance type) and
  Twilio console directly (trial account, no number, A2P not started, contrary to user's
  recollection — flagged for the user to confirm there isn't a second Twilio account).
- 2026-09-23 (Sonnet 5, later session): User confirmed Twilio A2P registration HAD been
  submitted and paid for ($20 charge) — my earlier "not started" read was wrong; verified
  properly via Trust Hub: Brand "AutoBuilt" Approved, Campaign Rejected (opt-in description
  errors). Root cause found: AutoBuilt (the platform) was registered as the Brand, but
  end customers only ever see the individual client business, not AutoBuilt — wrong entity
  for an ISV/reseller model. Talked through options with the user (per-client registration
  vs. billing complexity vs. using AutoBuilt's own approved brand for Austin's manual
  prospecting); user ultimately decided to drop Twilio entirely for now — no automated
  texts needed until a real paying client exists, since he handles his own outreach
  manually and mock mode already proves the automation logic works. Twilio is fully
  deprioritized; do not act on it again unless the user brings it up.
  Then built the real Cal.com webhook integration (see "Cal.com integration" section
  above): signature-verified webhook receiver handling created/cancelled/rescheduled
  bookings, idempotent via Cal.com's booking uid, service-linking via event type ID,
  per-business webhook secrets. Tested thoroughly against a local server (valid/invalid
  signatures, retries, cancel, reschedule, event-type-to-service mapping all verified
  via curl). Then configured Austin's own real Cal.com account as a live test rig:
  created a "Signature Fade" (45m) event type, required a phone number on the booking
  form, and wired a webhook straight at the (not-yet-live) demo endpoint with a secret
  that already matches what seed.js will create — so the very next GitHub upload makes
  a real Cal.com booking flow into the app with zero extra setup. Still pending: the
  user doing that one GitHub upload (auth + Cal.com code together) to make any of this
  live, then a real end-to-end test by booking a real slot on cal.com/austinbr/signature-fade.
